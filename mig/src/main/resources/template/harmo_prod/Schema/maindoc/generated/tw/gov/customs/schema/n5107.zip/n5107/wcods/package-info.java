//
// 此檔案是由 Eclipse Implementation of JAXB, v2.3.8 所產生 
// 請參閱 https://eclipse-ee4j.github.io/jaxb-ri 
// 一旦重新編譯來源綱要, 對此檔案所做的任何修改都將會遺失. 
// 產生時間: 2025.10.20 於 03:55:42 PM CST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "urn:wco:datamodel:WCO:DS:1")
package tw.gov.customs.schema.n5107.wcods;
